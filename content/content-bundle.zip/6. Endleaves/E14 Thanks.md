Every reader on Substack who kept me accountable as I attempted to share the book in serialised format.

To everyone who spurred me on, encouraged me with their feedback and kind words.

To my subscribers who signed up to travel on this journey with me. Thank you Janet Winter and Sarah Kennedy for being the first.

To Todd Brison who told me I was a good writer.

To Rosie Harriott, mentor and guide.

To Chris who always believed in me.