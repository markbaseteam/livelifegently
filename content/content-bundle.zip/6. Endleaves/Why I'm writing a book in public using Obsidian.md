Writing in public is a new thing I came across recently. I just liked the idea so I thought I would join in too!

## accountability

I thought sharing what I write publicly would keep me accountable, help me achieve my deadline, plus the potential of others reading my book could spur me on!

So far, this is working! While the current version is still very much in draft, I've created an outline, collated what I've been writing on the same theme which has given me a great starting point. 

In fact, now that I've started pulling everything together, I've written more than I envisaged.

## Obsidian

I've been harping on about my Obsidian obsession since April when I first came across this amazing note taking app. It has transformed my life in so many ways but especially my writing.

Unlike other tools I've tried over the years (Evernote, Bear, Scrivener), the concept of creating a digital garden with a tool like Obsidian (there are others such as Roam Research) includes the idea of notes at various stages of development. From seedlings to evergreen, content doesn't have to be finished but going through different stages of the process. Yes, you could use something like Evernote to create a digital garden but Obsidian lends itself to this format. 

It's a second brain in a way that no other app has been for me. And I've tried a lot! 

Where Obsidian comes into its own for writing is the ability to create links and backlinks. I love to create an outline where each chapter heading links through to the text. It means the writing flows more easily yet I don't need to organise the topics in the folder, just the outline.

Later, when I'm finished, I can use a plugin to compile the separate notes into a single format.

Because some of the content had already been created in other folders (I've been writing this book in various formats for a long time), I can simply move relevant notes into the book folder and link them in my outline. 

If I edit a chapter heading, it will automatically update any other links and the reference in the outline. Just like magic. 

I gather quotes and references - also in Obsidian - and I can pull in those references as blocks to populate a note. It's easy to search for a relevant quote or use tags.

The graph also lets me search through related themes.

