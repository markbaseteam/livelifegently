## Resources
- [[4. Gayatri Mantra]]
- [[4. Understand yourself]]
- [[Summary Sheet]]

Will
Dead Poets Society
The pen is mightier than the keyboard
https://journals.sagepub.com/doi/abs/10.1177/0956797614524581