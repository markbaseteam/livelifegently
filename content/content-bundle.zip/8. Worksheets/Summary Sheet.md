I am ….

  

I value

  

What I love about myself is

  

My big dream is

  

What I want to do differently 

  

My superpower is

Favourite book genre

Films

Hobbies

Secret joy

Favourite season

Drink

Secret dream

I help people best by …

I’m good at

I feel calm when I’m …

  

Others describe me as

  

In my best vision of myself, I am 

  

If I could do anything at all without the constraints of money or responsibilities, I would

  

Life’s challenges taught me that I am