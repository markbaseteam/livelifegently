I’ve thought for a long time that there’s more to life than we are been led to believe throughout our lives. We become deafened by outside influences, social conventions, status and the material world and, somewhere along the way, lose sight of who we really are. We become defined by our jobs, our roles, our to do lists, or our responsibilities. 

  

A part of us goes underground. This is the start of excavating that.

  

We carry on as normal but there comes a moment when something starts to niggle at us. We suspect, deep down, that we have more to offer but we don’t know how to find out what that is. 

  

We hear others talking about purpose and wish we could find ours. 

  

We get older and think it’s too late. It’s never too late.

  

We are more than just our physical bodies. There is some greater energy to which we are all connected and of which we are a part. Whatever you want to call this energy, (some call it God, the Divine, the Soul, or, as I like to, the Source), it is an organising force, present throughout the Universe, and we are made of the same stuff.

  

  

**My philosophy of life**

  

I’m sharing this with you to give context to some of the themes I mention. To me, there is no right or wrong. My philosophy of life is simply a point of view that works for me, and makes me happy. 

  

So this is what I believe.

  

We come into this world complete and whole. We are a soul in a body and are living this life time so that our soul can learn specific lessons and have certain experiences. We meet people along the way who are key characters in our story. These meetings are not by chance. In some cases we _recognise_ these people. Often our most difficult relationships hold the greatest life lessons.

  

Our lives on this planet are inextricably linked - and I think we have seen this a lot more in recent weeks. 

  

Life is much more than what we do for a living. 

  

One of the reasons why it’s good to look back on what we loved as children is that we still remembered what we were here for. I read recently that ages 0-7, are the key years when we are finding our way. It makes sense that this period should hold the clues for us, later in life. As we grow up, we develop amnesia and forget, then spend the rest of our life trying to remember. I call it a cosmic joke!

  

  

  

  

  

That makes us powerful too.

  

  

  

That nothing happens by chance, that our journey through life has definition, and we each have a role to play in our own lives and those of others.

  

I think our lives follow patterns with common milestones that we all encounter. Our paths might be different but there are shared experiences. 

  

That we are here for a reason, something far greater than just passing through and existing. We could have one pivotal moment that eclipses everything (think Captain Tom Moore) or a series of moments that give our life meaning. 

  

Perhaps we are here just to experience life. Or maybe find those things that bring us joy. It could be that we’re here to learn.

  

I’ve had a sense that there is something more for a long time. Maybe it’s because I’m an INFP - apparently the quest for meaning is a common denominiator. But perhaps it’s something else. 

  

Finding my place in the world means aligning with my essence, working and living in a way that feels aligned with who I am, matches my values and feels like flow. 

  

It’s finding a way to share my gifts and the uniqueness of who I am so that I can help others.

  

I think we find our purpose by being who we are meant to be. And that purpose may change and evolve over time. 

  

I think we all have something that we bring to the world. What that something is varies for each of us. It’s that thing that niggles away at us. It’s that dream. It’s almost intangible, it’s on the tip of our tongue. It’s the carrot on the stick dangling just out of our reach.

  

I don’t know if it’s down to my make up but I’ve felt this strongly throughout my life. There must be something more. This can’t be all there is.

  

I believe there is something more. That we are all here to be a piece of a bigger jigsaw. You can call it purpose. I call it essence. I have a strong sense that it we could just connect to our essence and be who we truly are, life changes around us and gives us a sense of fulfilment and meaning.

  

In the work I do with individuals I see that something. It’s that link between what challenges us and what we bring to the world.

  

  

  

Like many, I never felt as if I fitted in. There always seemed to be something a bit off about me. Others could be in the clique, the in crowd. I never was. I wasn’t popular. Often excluded from the groups.

  

I became used to it and learned to cope. It made me mentally tough and resilient. 

  

I became the person who would look out for the solitary networker standing on their own, the person with a disability being shunned because no-one knew what to say to them, the bereaved that no-one mentioned death in front of. 

  

I’ve always said the unspoken. That can be a double edged sword. I’ve always faced stuff face on.

  

  

How do you do that?

  

It’s taken me decades and it’s been an unraveling. I was very late to understanding who I was. I didn’t appreciate what being an introvert meant until I was 47. That changed everything for me. I finally understood why I had struggled to be heard in work, why I was rubbish at speaking up in meetings, why I couldn’t think on my feet, why I loathed phone calls and could come up with a hundred reasons why I couldn’t go to a social event. 

  

From that point on, I could work with who I was. I started telling my boss that, to get the best out of me in meetings, it helped if I could prepare for the discussion 24 hours in advance. If they wanted me to talk in a meeting, could they give me space to do that by calling on me to chip in my thoughts. It worked.