The Creativity Night Class 

How to develop your creativity, do what you really love and change your life. 

by Nicola Warwick 

"Every day the choice is presented to us, to live up to the spirit that is in us, or deny it”.  [Henry Miller] 

Creativity Course 

Qualifications – Nicola Warwick 

Business Manager for outsourcing company responsible for developing individual capabiities and skills.  Previously, internet consultant specialising in creative solutions for clients, both internal and external.  Responsible for creating innovation intranet to encourage creative thinking.  Software training and corporate presentation. 

Published “life’s little luxuries”, an original concept in 1997.  Book was sponsored by, among others, Richard Branson and received coverage in national press and a variety of glossy magazines. 

Columnist and author interviewer for “One Woman’s Writing Retreat” (http://www.prairieden.com) and author of several IT-related articles. 

Maintains various personal websites (including http://www.vanillasky.co.uk), involved in a number of creative pursuits including collage, digital photography and writing. 

Course Content 

Techniques: visualisation, brainstorming, brown paper, mind mapping, lateral thinking.  

Activities: poetry, letter writing, collages, journalling, chalking, creativity tests, doodling, outside speakers, automatic writing, visioning 

Topics: procrastination, mission (goal setting), time management, innovation, inspiration (art, people, places, play), inspirational people (failures and successes), creativity and spirituality, how to live your dreams 

Student work: morning pages, 5 minute writing, short story, 50/100 word stories, “just write”, scrap book, artist dates (gallery visits, museums, parks) 

Audience 

Adults (18+) 

No previous creativity experience required 

Evening or weekend class 

Course Requirements 

An open mind 

Notebook 

Pens 

Glue 

Scrapbook 

Old magazines/newspapers 

Scissors 

Week 1 (2 hours) 

1.  How creative are you?  [Psychometric type tests, creativity tests] 
    

2.  What is creativity?  [Individual, unique] 
    

3.  Explore skills using questionnaire  [Leisure interests, favourite films/books/music/art/places, preferred activities as a child, dreams without constraints etc] 
    

4.  Workshop skills questionnaire and build up 2-3 student profiles as examples to show different range of skills and influences 
    

5.  Aims and goals  [Discuss aims of course, what students hope to achieve] 
    

6.  Morning pages  [Intro] 
    

7.  Homework – artist date.  “Filling the well” 
    

Week 2 (2 hours) 

1.  Making time to be creative  [Procrastination, time management, goal setting, time wasters, prioritising] 
    

2.  Morning pages – review progress 
    

3.  Journal – 10-15 minutes to write about artist date 
    

4.  Discuss artist dates and interesting revelations arising from them 
    

5.  Mindmapping  [Explain technique] 
    

6.  Homework – collect items for collage, artist date 
    

7.  Remind students to bring collage tools for next week 
    

Week 3 (2 hours) 

1.  Visioning  [Explain technique] 
    

2.  Goal setting 
    

3.  Myths of creativity 
    

4.  Collaging 
    

5.  Heroes and inspirational people 
    

6.  Homework – keep collage journal for a week, write down goals 
    

Week 4 (2 hours) 

1.  Discuss inspirational people  [If they can do it, so can I] 
    

2.  Homework - who inspires you (research subject) 
    

Bibliography 

1.  How much joy can you stand? 
    

2.  The Artist’s Way – Julia Cameron with Mark Bryan (Jeremy P Tarcher/Putnam, 1992) 
    

3.  Vein Of Gold 
    

4.  Bird by Bird 
    

5.  Sark 
    

6.  Writing down the Bones 
    

7.  Leonardo book 
    

8.  Write it down, make it happen – Henriette Anne Klauser (Scribner, 2000) 
    

9.  Wishcraft – Barbara Sher (Ballantine Books, 1979) 
    

10.  Practical Intuition – Laura Day (Villard, 1996) 
    

11.  Think and grow rich – Napoleon Hill (Ballantine Books, 1960) 
    

12.  You can’t afford the luxury of a negative thought – John-Roger and Peter McWilliams (Thorsons, 1990) 
    

Resources 

1.  Philiphumbert.com 
    

2.  Cherylrichardson.com 
    

3.  Sark.com 
    

4.  Web 
    

5.  Yahoogroups.com 
    

6.  Class website  
    

7.  Buckminster Fuller 
    

8.  www.henrietteklauser.com 
    

Page Break  

Copyright © 2002 

by Nicola Warwick-Ball 

All rights reserved. No part of this book may be reproduced or transmitted in any form or by any means, electronic or mechanical, including photocopying, recording, or by any information storage and retrieval system, without the written permission of the publisher except where permitted by law. 

Page Break  

Hot Desk Publishing 

www.vanillasky.co.uk/ebooks 

First Edition 

Page BreakIntroduction 

I've been fascinated by Creativity for a long time.  How we improve our creativity, why some people are more creative than others and the fact that we're more creative than we believe.  This book sets out what I've learned, the books and resources I've found helpful and includes tools and techniques to help you build on your own creativity. 

As with many things in life I've found it to be true that “you teach best what you most need to learn” and that's a philosophy that is true here. 

I've taught a Creativity Night Class many times - in my head.  I've seen myself interacting with students, me sitting on a desk with my feet resting on a chair in front of me.  I've imagined various trips to museums, art galleries and other inspirational venues.  I've wanted to adopt an unconventional approach, to spur others to be unconventional themselves.  This is the curriculum in Palm format.  

The Creativity Night Class is aimed at anyone who wants to increase their creativity.  You don't have to be an artist, a painter, a writer or any of the traditionally “creative” occupations.  You just have to be someone who wants to increase their creativity.  You might end up being an artist, a painter or a writer as a result or you might end up being more creative in your daily life.  I hope this gives you something to think about and inspires you to think in new ways. 

Our Deepest Fear: by Marianne Williamson.  Our deepest fear is not that we are inadequate. Our deepest fear is that we are powerful beyond measure. It is our light, not our darkness that most frightens us. We ask ourselves, Who am I to be brilliant, gorgeous, talented, fabulous? Actually, who are you not to be? You are a child of God. Your playing small does not serve the world. There is nothing enlightened about shrinking so that other people won't feel insecure around you. We are all meant to shine, as children do. We were born to make manifest the glory of God that is within us. It is not just in some of us; it is in everyone. And as we let our own light shine, we unconsciously give other people permission to do the same. As we are liberated from our own fear, our presence automatically liberates others. 

Page BreakContent 

Techniques: visualisation, brainstorming, brown paper, mind mapping, lateral thinking.  

Activities: poetry, letter writing, collages, journalling, chalking, creativity tests, doodling, outside speakers, automatic writing, visioning 

Topics: procrastination, mission (goal setting), time management, innovation, inspiration (art, people, places, play), inspirational people (failures and successes), creativity and spirituality, how to live your dreams 

Student work: morning pages, 5 minute writing, short story, 50/100 word stories, "just write", scrap book, artist dates (gallery visits, museums, parks) 

Page BreakRequirements 

An open mind 

Notebook 

Pens 

Glue 

Scrapbook 

Old magazines/newspapers 

Scissors 

Page BreakWeek 1 

Week 1 text 

Introductions 

Choose a new name.  Make one up.  Be someone you admire.  Be a person from history.  Be your alter ego.  You choose. 

Choose a descriptive label.  Believer, Imagineer, Creator, Writer ... 

How creative are you? 

If you ask most people whether they're creative, the vast majority will probably say No.  Everyone has the potential to be creative.  In fact, you're probably more creative than you imagine.  It's just a question of channelling that creativity, making time to be creative and nurturing your creative abilities.  Yes, it takes work like anything else but it is also something that is inate in you, based on your own unique skills. 

Psychometric test links. 

What is creativity? 

It's a spark, it's imagination, it's that buzz you get when you do something you feel passionate about.  Creativity traditionally has “artistic” connotations but creativity can be applied to business just as well as any artistic endeavour.  It's about ideas, dreams, developing a flair for what you're good at, looking at life and things differently.  Thinking laterally, looking at things sideways on. 

You don't have to look creative.  I was astounded to find out that people thought I was wildly creative.  Outward appearances are deceptive.  Some people dress “creatively” but don't use their creativity at all.  It's all to do with what's in your head.  

The beauty of creativity is that, when you start developing your creativity the whole thing snowballs.  Creativity breeds creativity.  But you need to kick start it first. 

Aims and goals 

What do you like to do? 

A lot of clues to your creativity lie in your skills, interests, hobbies.  Make a list of all the things you enjoy doing.  They might be work-related, purely leisure activities, they might include activities you don't do now but would like to.  Write it all down.  

Creativity isn't about money either.  It's not about doing things that will generate revenue, it's about doing things that you enjoy.  The money will follow.  Think “Be, Do, Have”.  You have to \IBe\I first in order to \IDo\I the things you like to \IHave\I the things you want. 

Morning Pages 

One of my favourite books when I need inspiration is Julia Cameron's “Vein of Gold”.  Also the author of “The Artist's Way”, Julia advocates “Morning Pages”.  These are three sides of A4 paper, written in the morning.  It's stream of consciousness stuff, it's a case of keeping your hand moving across the page.  Just write.  

Some days you might not have anything to say.  “I don't have anything to say”.  That might be as good as it gets.  But persevere.  And one day things will fall into place.  You'll keep writing.  And later when you look back on your Morning Pages, you may see patterns emerge, you may start seeing answers to your own questions.  It's recommended that you don't look back on Morning Pages too soon.  Build up a collection of pages first. 

Morning Pages take a certain discipline.  

3. Explore skills using questionnaire  [Leisure interests, favourite films/books/music/art/places, preferred activities as a child, dreams without constraints etc] 

4. Workshop skills questionnaire and build up 2-3 student profiles as examples to show different range of skills and influences 

7. Homework – artist date.  "Filling the well" 

Page BreakWeek 2 

Week 2 text 

Making time to be creative 

[Procrastination, time management, goal setting, time wasters, prioritising] 

One of the biggest blocks to being creative is time - or lack of it.  In fact you already have enough time to be creative, it's a case of using your time wisely, prioritising, eliminating things that waste your time.  It's the start of a new phase in your life.  No more sitting watching soaps (after all, do they really make you more happy?).  Being creative is about having energy and eliminating those things that sap your energy.  Make the most of your energy, spend it wisely.  Alan Cohen[2] talks about those things that drain our energy.  The question is not whether there is life after death but whether there is life before death.  Stop doing those things that deplete your energy - you know what they are or who they are.  That friend who leaves you feeling drained after you've met up, you know the one who moans non stop.  The job that leaves you exhausted and fit for nothing at the end of the day.  Maybe it's not practical to just quit the dayjob but put a plan in place to enable you to move on to something that brings you joy. 

Do those things that expand your energy.  Do what brings you life.  Do not do those things that deaden you - and you know that feeling.  If you are not where you want to be because you are doing those things you don't want to do, then move.  Quit.  Stop.  Change.  Look at your life and identify what sucks - the people in your life, the things you do.  What do you love?  Keep doing those things.  Expand those things.  When you invest time and energy in things that drag you down, you die a little.  So, stop, and live a lot.  Don't let your life be reduced to a dribble. 

Simplify your life.  The simple pleasures in life actually give you more joy than big expensive pleasures.  Spend time in nature, eat yoghurt, spend time with animals. 

Be careful what you pay for with your attention.  Invest in things you value, collect interest and be interested along the way.  Make everything you do an investment.  

The more you get involved in something, the more the involvement grows.  If you truly enjoy something, then dive in.  Walk away from what doesn't serve you.  That may include people.  There is no redeeming value in misery. 

Morning Pages - progress review 

Journal 

10-15 minutes to write about artist date 

Artist dates 

Interesting revelations arising from them 

Mindmapping 

Homework 

Collect items for collage, artist date 

Page BreakWeek 3 

Week 3 text 

Visioning 

[Explain technique] 

Goal setting 

Myths of creativity 

Collaging 

Heroes and inspirational people 

I read lots of biographies, collections of letter and diaries.  I love getting an insight into the lives of people I admire.  People like Ernest Shackleton, TE Lawrence, Richard Feynman.  

Homework 

Page BreakWeek 4 

Inspirational people 

[If they can do it, so can I] 

Homework 

who inspires you (research subject) 

Page BreakBibliography 

Creativity 

How much joy can you stand?,  

The Artist’s Way, Julia Cameron with Mark Bryan (Jeremy P Tarcher/Putnam, 1992) 

Vein Of Gold, Julia Cameron 

Bird by Bird, Anne Lammott 

Sark 

Writing down the Bones, Natalie Goldberg 

Leonardo book 

Write it down, make it happen, Henriette Anne Klauser (Scribner, 2000) 

Wishcraft, Barbara Sher (Ballantine Books, 1979) 

Practical Intuition, Laura Day (Villard, 1996) 

Think and grow rich, Napoleon Hill (Ballantine Books, 1960) 

You can’t afford the luxury of a negative thought, John-Roger and Peter McWilliams (Thorsons, 1990) 

Our Deepest Fear by Marianne Williamson from A Return To Love: Reflections on the Principles of A Course in Miracles 

Creative people 

Inspiring people 

Philosophy 

Why your life sucks and what you can do about it, Alan Cohen 

Biographies 

Ernest Shackleton 

TE Lawrence 

Richard Feynman 

Letters 

Jack Kerouac 

TE Lawrence 

Journals 

Virginia Woolf 

Anais Nin 

Page BreakResources 

1. www.philiphumbert.com 

2. www.cherylrichardson.com 

3. www.campsark.com 

4. Web 

5. Yahoogroups.com 

6. Class website  

7. Buckminster Fuller 

8. www.henrietteklauser.com 

9. www.sabrinawardharrison.com 

Page BreakPlay 

“Play” and “work” often appear as two distinct ideas at opposing ends of the spectrum.  How can you have fun at work?  

Look for possibilities in each employee instead of the negatives. 

Autonomy. 

Empowerment so that staff don’t have to wait to be told what to do. 

Give them some slack and then don’t take it back again. 

Be consistent. 

Build. 

Incentivise/motivate. 

Staff need satisfaction and fulfilment.  Doing something worthwhile. 

Duty of care for employees. 

Need to try things.  Take risks.  Be open to mistakes, things going wrong.  If it doesn’t work, change it, try it again. 

Find solutions that work all round. 

Page BreakFeed your spirit 

You need to consciously feed your spirit otherwise it, and you, will atrophy. 

Life is so much a daily grind.  Full of commitments and must dos.  It’s easy to lose sight of ourselves in the rush to get to work, look after the family and see friends. 

Simple things like going to see a film can make a difference.  It’s pure escapism.  If you can, go on your own then you can really get carried away.  Go to see something uplifting. 

Often we find the solutions when we’re doing other things.  Allowing our brains to take time out.  Do something else and quite often you came up with the idea of inspiration you’re looking for. 

The spirit needs nurturing/feeding.  It’s not a never ending well.  It’s like a car.  If you don’t keep it topped up with oil and petrol it won’t get you very far. 

Alpha waves 

Archimedes 

Feynman