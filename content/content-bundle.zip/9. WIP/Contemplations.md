Reconnection

Community

Creativity

Alignment

Compassion

Flow

Self-care

Empowering

Sovereignty

  

We have to slow down

  

To step away from the norm and embrace a different pace of life

  

It's challenging. It's so easy to default to what we've been used to. Stay in our comfort zone.

  

If we do that nothing changes.

  

Yet the world is changing around us, whether we like it or not

  

The way forward is through flow

  

It's so easy to push hard, to try to be productive and do more. The answer is to do less, to allow, to go with the flow.

  

It's hard to do after a lifetime of crushing it. A lifetime of ignoring the natural cycles. Everything we have been taught is up for review.

  

We are the creators who can choose the life we want. We create our world.

  

If you want a world of peace, create it. The world around us is defined by us.

  

It is our creation.