But change

Heraclitus