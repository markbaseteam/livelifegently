# A Gentler Pace

## Navigating the route map to your essence

Description of *essence*
Definition/roots

> When you experience unity of intention, fascination, and purpose, you live like a bloodhound on a scent, joyfully doing what feels truest in each moment. Your daily work, whether it’s writing computer code, gardening, or building houses, is so absorbing that at the end of the day you don’t really want to stop. But when you do, you enjoy hanging out with loved ones so much, and sleep is so delicious you can’t imagine anything sweeter. And when you wake up the next morning, the day ahead seems so enticing you practically bound out of bed.[^1]

Essence is about alignment. With ourselves, our values, our joy. It's about traveling our own path. 

It's about being a rebel, not conforming to societal norms. It's not about people-pleasing.

We abandon our true nature and become pawns of our culture: smiling politely, sitting attentively, wearing the “perfect” uncomfortable clothes. This is why a soldier will march into gunfire without complaint. It’s why whole communities once thought it made sense to burn a few witches here and there. The extent to which people will defy nature to serve culture can be truly horrifying. But the whole thing works very well from the perspective of creating and sustaining human groups.[^2]

However much we try to conform, our inner nature is fighting back.

My Mum and I had a difficult relationship because we were poles apart in our view of the world. I gravitated toward and unconventional take on life while my Mum was very traditional. I was a quiet rebel, always questioning why things were the way they were. My Mum was a force to be reckoned with and it became easier to go with the flow as much as possible. Even then I still didn't fit the mold. I was too fat, my hair was too long, my clothes were not to my Mum's taste. There was no room to be me. For years, in my Mum's presence, I was a shadow of myself. 

Of course, this has a knock on effect on other areas of your life. I became adept at concealing parts of myself with others as well as with my Mum. I presented what I thought people wanted to see and felt permanently out of kilter.

Even now I can still revert to this behaviour but I know what I'm doing.

We need to be our whole self.

The inner manifests in the outer.

Out of kilter/alignment.

Feel like we've lost part of ourselves.



[^1]: Beck, Martha (2021-04-12T23:58:59). The Way of Integrity: Finding the path to your true self . Little, Brown Book Group. Kindle Edition.
[^2]: Beck, Martha (2021-04-12T23:58:59). The Way of Integrity: Finding the path to your true self . Little, Brown Book Group. Kindle Edition. 