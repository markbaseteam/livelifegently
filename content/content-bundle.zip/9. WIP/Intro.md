The seeds of A Gentler Pace were sown several decades ago. I can’t pinpoint the exact moment but I remember the grumblings of discontent in my early thirties when I started to think that there must be more to life than _this_.

  

_This_ was most often work. Supposed to take me up the career ladder, always on a quest to do more and do better, the lack of any sense of fulfilment led me to live for the weekends and wish the weeks away. I changed jobs so many times that my CV was like a patchwork quilt. Fortunately, in my thirties and working in internet-related businesses, I was made redundant several times giving me a legitimate way out. 

  

But each new job quickly became like Groundhog Day. A different business, a new role but the same challenges applied. I missed the daylight in Winter when I was often cooped up in an office (at one point working in a place known as the Hen Coop because of its lack of windows). I yearned for the trees in my local park. My ideal day was simply to drive in and spend hours there. Punctuated with a latte or two in one of the many cafes. Just taking photographs and walking, this was where my creativity was sparked. It was where I found my flow.

  

Of course, I did nothing about it. One job succeeded another. I paid my bills but had little else to show for my endeavours at the end of the month. Work seemed like a bad habit I was supporting. I didn’t know how to find a way out. Not at that point anyway.

  

  

  

  

I’ve always been unconventional. My Mum used to say I was too unconventional as though it was a bad thing. But I couldn’t help myself. My thought processes weren’t born out of awkwardness but from a deep seated urge to challenge the way things were done. I would feel it rise up from my gut insisting that I take notice. 

  

My Mum was very traditional and I questioned what had always been done, wanting to innovate and find a new/better/different way. Over time I began to suppress my unconventional streak although it still popped up now and again, mostly when I was sitting in bone crushingly boring meetings wondering why I was there and how this added to human happiness. I was probably in my early thirties when I really started asking myself, is this it? 

  

I didn’t have an earth shattering moment as many people do which awakens them and gives them the kick in the seat of the pants they need to completely transform their lives. I plodded on, changing jobs on a regular basis, hoping against hope that this one would be ‘it’. Six months in and I would be back to square one. Surely there’s another way but I didn’t know what that looked like.

  

In the years before my Mum died I experimented with self-employment but simply replicated work as I knew it, working every hour I could, often with people I didn’t like. I still had a lot to learn and I hadn’t realised at that point that I had to do things my way.

  

In April 2019 a similar nudge led me to leave my then day job as a Business Advisor. I was at a crossroads. I was mid life, menopausal, mid 50s, both my parents had died and mortality was knocking at my door. There must be another way and I had to find it.

  

That decision was a catalyst for a move to a part of the country I love and, as I sit here writing, I’m now in my bijou study in a rural village somewhere in the middle of nowhere, Derbyshire. The culmination of a long held dream and part of this journey to live at a gentler pace and on my own terms.

  

The road hasn’t always been clear. Apart from the 4 or 5 months of downtime after our move and before our new house was ready, I bobbed about, play acting being busy, working for myself. Writing a few blogs here and there, recording some podcasts, taking photographs, posting on Instagram but, all the while, keeping firmly below the parapet. I was still almost invisible. I was embracing the idea of forging my own path but not really doing anything about it. 

  

At the same time we headed into lockdown 1.0, 2.0, 3.0 etc. Life was changing for everyone. 

  

What I had to say and share was very relevant but still I stayed silent and danced around the handbags. 

  

Since my mid twenties I started to follow a more esoteric path. I’d concluded by the time I was 18 that I didn’t believe in God. Despite years of church and Sunday school, I was drawing a very different conclusion. I read mind body spirit books like it was going out of fashion. Although I had no idea at the time, I was on a quest. 

  

I was drawn to crystals, I was looking for insight. I decided to do a Reiki I course. I was happy with that until I kept being nudged to do Reiki II. I was done at that. And then I was nudged to do Reiki III and later the teacher qualification. Something was happening but still this part of my life was kept under wraps.

  

I continued working in conventional jobs and wondering what it was all about.

  

I began to think a lot about essence. I talked about the whole self. I came to the realisation that we are all divine - we are all god. 

  

Then we headed towards 2012. I dived down countless rabbit holes trying to understand what was happening and what this shift meant. I felt called to be part of it and hosted a Cosmic Circle, a meditation group in my house. I did a lot of, what you might call, spiritual work.

  

After 2012 the group disbanded. It had served its purpose. My Mum was poorly and my life for the next 4 years changed. Much of my alternative life was on hold as first my Mum died and then my Dad. 

  

My life changed out of all recognition as first I met Chris, a completely blind man, who would become my husband in 2018, I left my job, we decided to sell the house and relocate to Derbyshire. We say so often that we can’t believe how much life has changed since 2015, for both of us.

  

I believe none of what happens in our lives is by chance. Life takes us on the journey we need to travel. It nudges us again and agin until we finally listen to our calling.

  

We are all more powerful than we dare to admit. We live in a world where we are told, from a young age, that others know better, that politicians and officials have our best interests at heart and we should listen to their guidance, teachers give us an accepted view of history. By the time we exit the school system most of us have lost our spark. We believe that the path that lies before us is most likely made up of working our way up the career ladder, doing jobs that leave us unfulfilled, marrying and having 2.4 children. Between 20 and 60 our life purpose is to work hard enough to be able to pay the bills and support our families, have a couple of holidays a year, and not think too hard about what our lives mean. 

At some point though we might start to think that there must be more to life than … this. Whatever this has turned out to be. 

At some stage, perhaps around the Menopause for women, we are nudged out of our stupor. We might become disenchanted with our lot in life. That job that we've been attending for years suddenly palls. What does it mean? Why are we doing it? The whole idea of working for a living, working to pay our bills is no longer enough. Perhaps our parents have died or others close to us waking us up to the idea that our mortal clock is ticking. How much longer do we have and how are we going to spend this precious time? Are we just going to sit and give our energy to someone else's agenda or are we going to dig deep within, reconnect to that spark that we had as a child, rediscover our essence and follow a whole new path? 

I've always believed that we had the potential for greatness. I just didn't know what it looked like. I thought it was something that other people could tap into and I wasn't one of the lucky ones. It was just the chosen few who could find their genius and put it out into the world. It wasn't meant for mere mortals like me. 

But, over the years, I came to some realisations. That we are all immensely powerful. We are all destined for greatness. We each have a unique genius that we bring to the world and the world needs us to share our genius with the world, especially now, at this pivotal moment in our history. 

… 

I'd felt the nudge to live in a different way for a couple of decades. I'd never found fulfilment in my conventional day jobs even though I was on a path, building my career and climbing the rungs of that ladder. 

I had many moments when I wondered what it was all about. Work seemed to have little purpose in itself, apart from funding the payment of my household bills. I often felt that work was just a bad habit. I couldn't see an alternative back then so plodded on, every now and again changing jobs when it became unbearable, hoping that this latest role would be different and would light the spark within me. It never happened. 

Eventually, at the age of 54, I decided I was done. Both the deaths of my parents had stirred me from my stupor – for a while anyway. The realisation that I was now the last of the line, I was heading to the big hereafter, who knew when, 

  

One of my favourite films is The Adjustment Bureau. I reference it often as I love the concept of each of us having a book of life with a road map and intersections where we meet others and fulfil our destinies. While I’m not fatalistic, I do believe that each of our life’s journeys is punctuated with milestones, crossroads and roadblocks. They lead us to certain people and experiences that we are meant to encounter. It’s only when we look back that we can see the path that has brought us to where we are today.

  

When my Mum died in October 2013, I had no idea that just 2 years later I would have met the man I would marry in my fifties. I was happily single, living alone and forging my own path in the world. At the time I envisaged I would be single for the rest of my life. For me, back then, being unattached and independent was a happy prospect. Five years after my Mum’s death I would find myself married to a blind man and on the verge of a life changing move to a more rural area of the country. 

  

In April 2019, I quit my then day job to set up on my own. Quite what I was going to do, I really wasn’t sure, and there would be a few twists in the tale before my future started to unfold.

  

I’d followed with interest the idea of slow living until it became so widespread it lost its appeal for the maverick me. But there was something in it that I liked. I was tired of the constant hustle of working for someone else. The relentless wake up at 05:30 to beat the 2 hour traffic jam into Manchester. The dark mornings. Barely seeing any daylight. Sitting in meeting after meaningless meeting. Jumping through hoops of company policies that seemed to have no value or purpose. Worst of all attending the annual company meeting, being compelled to network with colleagues who were all counting the hours before they could go home, and listening to managers who were removed from the everyday business of our work.

  

Day after day passed. My life was eroding 

  

I suspect there comes a time, or maybe even several occasions, when we each want to make alterations to our lives. Something shifts. That job we once loved, we begin to loathe. The head over heels relationship fades away. Our house no longer feels like the home it once was.

  

Whatever the reason, a new game is afoot. 

  

In April 2019, a woman called Joy Marsden died. Although I’d only met her once I had been captivated by her eloquence and energy (even though she was unwell that day). She made a huge impression on me and when I learned that she had died, it was both a catalyst and a pivotal moment that challenged me to think about what I was doing with my life.

  

In that moment it seemed very clear. I could either carry on as I was, as time ebbed away, or I could do something else. Either decision could appear foolish depending on your perspective. By Sunday evening my resignation letter was ready.

  

It hasn’t all been plain sailing. Starting a business from scratch takes time, especially when it’s unconventional, isn’t fully formed in your head and needs a lot of work. What I’m doing now is very different to how I began. But nothing is ever lost and foundations have been laid.

  

Six months after I left my day job we decided to move house and relocate two hours down the road. While the next year wasn’t my most productive, it was an opportunity I needed to let go of my life with my Mum and Dad, and step forth entirely on my own. Their deaths were both pivotal moments for me. We had been a close knit family and, despite my prized independence, a line had been drawn when they died. 

  

I sold furniture. My Dad’s 21st present from his Grandma. My Mum’s cherished Welsh dresser. The dining table where we sat every Christmas. The rocking chair my Mum and I had sat in when I was small. I had to be ruthless. They all had memories but weren’t necessarily things I loved. An only one, there is no-one after me. When I’m no longer here, whatever is left will just be cleared away without ceremony. I decided it was better to do the job myself. I photographed everything so there’s still evidence. Strangely many items went to the right people. My childhood model garden went to someone who had the same garden but was missing some parts. My collection of smurfs went to another collector. The Welsh dresser went to a lady also called Vera. 

  

As I sold items, the process gained momentum, and I parted with as much as I could. I pared back although I couldn’t bring myself to recycle the hundreds of birthday, anniversary and Christmas cards we had sent to each other over the years. I boxed those up for another day. I kept my Mum’s collection of Swarovski crystal, hand painted china and balloon people. But I sold most of my Mum’s jewellery, using the proceeds to have a necklace and ring made from the stones in her engagement ring. I’d already used the gold for my own engagement ring.

  

I gave away two sets of china. They would have sold for next to nothing but had a second life at our local tearoom. I had daily visits to the charity shop until I was on first name terms with the staff.

  

My Mum might have been mortified with my decision. She had looked after everything my Mum and Dad owned during 56 years of marriage. They were prized possessions but they weren’t mine. They were part of my history but not my future.

  

When we finally move into our new house, it will be with what we need and love. My Mum and Dad will still be remembered in lots of things, just not everything.

  

The time I had was needed to go through this catharsis, to declutter and let go. It might not have progressed my work but it was important work.

  

I did record two series of a podcast, wrote some blogposts, helped Chris with his woodturning, started growing an Instagram account.

  

Make changes! Wherever you live, whatever your circumstances, if the pace of your life doesn’t suit you, then change it! It’s as simple as that.

  

In September 2019 Chris and I spent a few days at one of our favourite places, Biggin Hall Hotel. It was our third visit and, as I always did when I visited Derbyshire, at some point I said, I wish I could live here. Chris said, what’s stopping us?

  

I’d visited Derbyshire many times. Often popping over for a day at the weekend, visiting Buxton and some of the nearby villages. It was just over an hour’s drive from home at the time. 

  

I discovered a tiny hamlet called Wormhill when one of my friends stayed there and I visited her. They had rented a converted barn and that was the turning point for me contemplating this different type of life. I loved the peace and quiet. The vast green landscape. The livestock. I loved Wormhill because there was very little there. A road running through it, several farms, a Manor House, a church, a village hall. I was so taken with it that I booked to stay in the same converted barn the following year. I could see myself living the country life. I could see myself embracing the peace and quiet. 

  

I befriended a field of cows - a highlight of my stay. I loved them and visited them a couple of times each day. By the end of the week they looked out for me and lined up at the fence in greeting.

  

I thought that my Derbyshire dream was something I would do later. When I retired. When I finished working. Later.