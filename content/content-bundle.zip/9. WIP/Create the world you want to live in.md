Our lives follow a pattern. For most of us, that pattern was set a long time ago. We chose to embrace a story about compliance and convenience, the search for status in a world constrained by scarcity. The industrial economy demands it. It prods us to consumption and obedience. We trust the system and the people we work for to give us what we need, as long as we’re willing to continue down the path they’ve set out for us. We were all brainwashed from a very early age to accept this dynamic and to be part of it. ^23f3bc

  

Godin, Seth. The Practice (pp. 5-6). Penguin Books Ltd. Kindle Edition. 

  

Seth Godin puts into words so eloquently what I’ve thought for many years. Life seemed to corral me in a particular direction. My Mum, being a great traditionalist, wanted my life to take a set route. She hoped I would be a Doctor, marry another Doctor and have no children. (She didn’t want grandchildren). Becoming a Doctor wasn’t part of my life’s plan but I pursued a career in my own way, always clinging to the ladder, aiming for the next rung, that next step closer to ‘it’, whatever it was. Like a carrot dangled just ahead of us, I never attained ‘it’. 

  

The industrial system that brainwashed us demands that we focus on outcomes to prove we followed the recipe.

  

Godin, Seth. The Practice (p. 6). Penguin Books Ltd. Kindle Edition. 

  

I felt constantly stymied. Paying my bills seemed like a bad habit that I had to fund by constantly working. My persistent question to myself was, is this all there is to it? There had to be another way.

  

The industrial system we all live in is outcome-based. It’s about guaranteed productivity in exchange for soul-numbing, predirected labor. But if we choose to look for it, there’s a different journey available to us. This is the path followed by those who seek change, who want to make things better. It’s a path defined by resilience and generosity. It’s outward focused, but not dependent on reassurance or applause.

  

Godin, Seth. The Practice (p. 7). Penguin Books Ltd. Kindle Edition. 

  

That other way is very different. Even as I’m writing this I question myself and my belief that I can make this work. It requires us to step so far out of our comfort zone and, if we have friends and family who think out actions are nuts, we have to contend with their comfort zones too. To extricate ourselves from this industrial system and forge our own path takes immense courage, a willingness to fail, a deep desire to follow our heart. 

  

It means listening to that relentless inner voice that whispers to us: you’re wasting your life, you can be so much more than this, you have so much to offer, you’re here for a different purpose, when will you do something that fulfils you and brings you joy?

  

We’re living at a time when massive shifts are taking place in the physical and spiritual worlds. I ask myself every day, what sort of world do you want to live in? I know I have to create that world for myself. And that’s what I do. 

  

What sort of world do you want to live in?

  

It’s easy to believe that we have no control. Even with everything going on in the world around us, we can create our own world.

  

Think about how you want to feel. How do you want to spend your time? 

  

I want to be able to breathe fresh air. To walk outside. To see trees and fields and, if possible, cows. I want to be able to work on projects that are important to me. To share my ideas, to help other people bring their ideas to life. 

  

I want to live in balance and alignment with who I truly am. To feel that I’m not compromising myself to fit in but have the freedom to be me. 

  

What are your values?

  

Perhaps I’ve created a little bubble for myself. But that works for me.

  

Over the years I first stopped watching the news on television. I stopped watching television altogether. We pick and choose what we watch on Netflix or on DVD. I stopped reading the news. I deleted Twitter from my phone. I pared down my Facebook account and carefully curated what I see there. 

  

I have a rule - if it doesn’t make me feel good, then it goes. I am careful about my inputs. I want inputs that bring me joy and happiness. That are positive and make me feel positive. 

  

Believe me when I say I don’t miss the news at all and I’m informed about the high level goings on in the world without getting bogged down in the minutiae. 

  

What happens when you turn off these inputs is that you have the headspace to think for yourself, to make up your own mind, to give your creativity the opportunity to flourish independent of other inputs.