When the power of love overcomes the love of power the world will know peace.” _– Jimi Hendrix_

> The good inside of all of us is wrapped in a layer of apathy, and we forget how much potential we have within us, in each and every one of us, to change the world for the better for ourselves and our children, and thus to bring about oneness.” _– Shari Arison_

> Never doubt that a small group of thoughtful, committed, citizens can change the world. Indeed, it is the only thing that ever has.”
> 
> ##### Margaret Mead
> 
> The world as we have created it is a process of our thinking. It cannot be changed without changing our thinking.
> 
> ##### Albert Einstein
> 
> It’s a philosophy of life. A practice. If you do this, something will change, what will change is that you will change, your life will change, and if you can change you, you can perhaps change the world.
> 
> ##### Vivienne Westwood
> 
> Everyone thinks of changing the world, but no one thinks of changing himself.
> 
> ##### Leo Tolstoy
> 
> You never change things by fighting the existing reality. To change something, build a new model that makes the existing model obsolete.
> 
> ##### Richard Buckminster Fuller
> 
> Rather than the need to heroically save the whole world, the real work of humanity at this time may be to awaken the unique spark and inner resiliency of genius within each person.
> 
> ##### Michael Meade
> 
> Out of this darkness a new world can arise, not to be constructed by our minds so much as to emerge from our dreams. Even though we cannot see clearly how it's going to turn out, we are still called to let the future into our imagination. We will never be able to build what we have not first cherished in our hearts.
> 
> ##### Joanna Macy
> 
> Cosmos is a Greek word for the order of the universe. It is, in a way, the opposite of Chaos. It implies the deep interconnectedness of all things. It conveys awe for the intricate and subtle way in which the universe is put together.
> 
> ##### Carl Sagan, Cosmos

> Our lives follow a pattern. For most of us, that pattern was set a long time ago. We chose to embrace a story about compliance and convenience, the search for status in a world constrained by scarcity. The industrial economy demands it. It prods us to consumption and obedience. We trust the system and the people we work for to give us what we need, as long as we’re willing to continue down the path they’ve set out for us. We were all brainwashed from a very early age to accept this dynamic and to be part of it.
> 
> ##### Godin, Seth. The Practice (pp. 5-6). Penguin Books Ltd. Kindle Edition.

> The industrial system that brainwashed us demands that we focus on outcomes to prove we followed the recipe.
> 
> Godin, Seth. The Practice (p. 6). Penguin Books Ltd. Kindle Edition.