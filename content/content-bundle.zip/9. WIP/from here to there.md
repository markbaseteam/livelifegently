Unbroken: the Song of You 

Premise 

#migrate 

There is nothing wrong with you or me. We have just encountered a series of life experiences and not learned how to navigate them or understand the route map. 

Outline 

Why unbroken? 

How can you go from feeling broken to recognising your unbrokenness? 

You don’t have to follow the crowd 

To shine you have to stand out - embracing your own light 

You are more powerful than you have every imagined 

The world needs people who live from joy 

Where you end up: the whole self 

Introduction 

It took me a long time to realise that I wasn’t broken or needed to change. While I still have moments when I relapse into those beliefs, the majority of the time I accept my quirkiness, my eccentricities and understand that these make me the unique person I am. 

A lot of self-development starts from the premise that you are broken and therefore need to be fixed. I don’t subscribe to this view. I believe that you are unbroken, you’ve perhaps just lost your way, gone off piste or life has sent you down paths that have taken you away from your centre. 

What’s needed is a realignment.  

Often we know who we really are but life, work, finances and family often teach us that we need to conform. We need to live our lives in a certain way in order to fit in.  

What happens is we suppress the best parts of who we are. We wander away from our core essence until who we present to the world is diluted. Consequently we feel that our lives and us are broken and need to be repaired.  

We just need to find our way again. 

That can be easier said than done.  

It involves feelings of guilt, self-doubt and requires risk taking. It is a journey that takes us back home, to who we were meant to be all along. 

That journey leads us up hills and down dales, along circuitous routes, eventually bringing us back to where we started from - home. 

What I wish I’d had 

I wish someone had told me years ago that there was nothing at all wrong with me but that people would try to convince me there was. That I didn’t have to subscribe to the mortgage, 2.4 kids, husband to be successful. Or that I needed a job of a certain calibre to have made it. 

Having said that, our experiences are never wasted and while I might wish that I hadn’t spent my 30s working so much - to the extent that I have little or no memory of anything other than work - it helped me find out who I wasn’t, and also equipped me with skills that became useful later on. 

You can’t have something without having experienced its opposite. I remember craving daylight on dark Winter days when I arrived at work when it was still night and left work when the day had ended. I dreamed of spending days in the park or in the countryside, walking, and taking photos. 

Now, at 55, life seems to have whizzed by. It was only five minutes since I was leaving school. My 20s seem a blink of an eye ago. My 30s passed in a blur. And my 40s were about work and wondering if I was always going to be single. 

Salvation can come at any point in your life. Everyone’s life is different. Some people know what they want to be when they grow up at an early age. Others, like me, never really know. 

Perhaps it’s more important just to enjoy and appreciate life, do the things that you love and prioritise what’s important to you. 

Don’t follow the crowd 

From birth we are corralled - we’re sent to kindergarten where we start to learn to fit in. Our behaviour is rewarded when we behave in certain ways. Those children who try to be themselves are branded as awkward or trouble makers.  

Education is not equipped to help children express who they are - it tries to knock any original thought out of them and squeeze them through a tube to become another adult from the production line. 

We have an accepted path through life - and this path is often devoid of joy. Too many people do jobs that they don’t enjoy or even actively hate. By that time, there seems to be no escape as we are saddled with mortgages, bills and family to support. We’re in a vicious circle. 

Make a plan 

Dream! Dream big. What do you really want to do with your life? 

Here’s a wake up call for you. None of us is getting out of this alive. I say that with some humour but one day we will all end up in a box and our lifetime on this planet will be over. 

We think we will live for ever, or that there will always be time but eventually that clock stops ticking. 

I first really grasped my own mortality after my parents died. Until then I felt somehow immune because I was their daughter and in the natural cycle of things, I would be here long after they were gone. But then they died, one after another, and the message drove home. This life is not forever.  

Somehow I found myself, aged 55, few of my dreams realised, a lifetime of work behind me and very little to show for it. 

All those jobs on my CV? Meaningless really. I doubt many people even remember my name. All that work I did - it was really just shuffling papers around a desk, doing a lot of activities that no-one was interested in or that never saw the light of day. So much time wasted. Weeks spent on motorways driving around the country.  

Attempts to climb the corporate ladder. Sometimes your face fits and sometimes it doesn’t. And sometimes that job that you thought you wanted is simply a poisoned chalice.  

Did any of the work I did contribute to the greater good? Did it make the world a better place? I don’t really think so.