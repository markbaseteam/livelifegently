The seeds of A Gentler Pace were sown several decades ago. I can’t pinpoint the exact moment but I remember the grumblings of discontent in my early thirties when I started to think that there must be more to life than _this_.

  

_This_ was most often work. Supposed to take me up the career ladder, always on a quest to do more and do better, the lack of any sense of fulfilment led me to live for the weekends and wish the weeks away. I changed jobs so many times that my CV was like a patchwork quilt. Fortunately, in my thirties and working in internet-related businesses, I was made redundant several times giving me a legitimate way out. 

  

But each new job quickly became like Groundhog Day. A different business, a new role but the same challenges applied. I missed the daylight in Winter when I was often cooped up in an office (at one point working in a place known as the Hen Coop because of its lack of windows). I yearned for the trees in my local park. My ideal day was simply to drive in and spend hours there. Punctuated with a latte or two in one of the many cafes. Just taking photographs and walking, this was where my creativity was sparked. It was where I found my flow.

  

Of course, I did nothing about it. One job succeeded another. I paid my bills but had little else to show for my endeavours at the end of the month. Work seemed like a bad habit I was supporting. I didn’t know how to find a way out. Not at that point anyway.