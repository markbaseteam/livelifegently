How many days have you spent, often as part of your working life, never seeing daylight.

At one point I worked in a place known to the staff as the Hen Coop. The offices were located above the warehouse. It was brieze block. There were no windows at all. We sat in our cars at lunch time to eat because the staff canteen was so depressing. I lasted 7 weeks. For a number of reasons, it wasn't the job for me, but lack of windows was a big factor.

For many years, I used weekends to top up my light quota. I would race to the park on a Saturday morning, anxious not to lose the light. I'd be there from the crack of dawn. It became essential. Those hours in the park were my sanctuary. During the week I would drive past the park gates and gaze longingly at the trees and open spaces, on my way to work. I lived for my weekends.

