I didn’t consciously ask myself, what sort of life do you want to live? My dream to do my own thing while living in the Derbyshire countryside was pie in the sky for many years. Something I thought I would do … later. 

  

But I did write in countless notebooks describing the life I had in mind. No more 9-5. Lots of time spent outside, in nature. Lots of trees, wide open green spaces. Time to take photographs. To make a living doing something less than conventional. To be able to spend time with cows. 

  

The lists ended up being very similar, even though I was writing them over a period of 20 years or more. When I finally found myself living in Derbyshire, it came as a bit of a surprise. And it proved, as if I needed it proving, that there is power in writing things down.

  

I used to write goals every year. Some of them were crazy goals. From my teens to early thirties I was quite star struck and loved meeting some of my favourite actors or people in the public eye who I admired. I collected autographs, first by post and then in person when I realised that I could hang out at stage doors. I lived in London by then and went to the theatre a lot. I probably had specific names on my lists. I know, when I reviewed the list at the end of the year, well over 90% had been ticked off. 

  

I would write my list and then put it away. I wouldn’t keep looking at it and still it worked.

  

I do think there is massive power in writing things down. It does something to your brain. It puts it on notice to look out for opportunities.

  

I’m convinced too that our vibration and frequency impact our ability to make dreams come true.