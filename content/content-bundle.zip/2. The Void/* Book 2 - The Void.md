**Chapter 1**

[[2.1 The Void - Retreat]]
[[2.2 Un-becoming and letting go]]
2.3 Creating the new
[[2.4 Finding flow]]
[[2.5 Spend time in Nature]]
[[2.6 Making and creating]]
2.7 The Void in the world
2.8 How the world reflects these stages

- [[2.1 The brain is a receiver]]
- [[2.2 Evolve or remain]]
- [[2.3 Decluttering]]
- [[2.4 Creativity is the route to our divinity]]