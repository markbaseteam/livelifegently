My fascination for alternative world views began early. I had no trouble believing that there were [other worlds](https://www.agentlelife.co.uk/essencemap/) out there in the Universe and, ergo, other life forms. That fascination never diminished and only grew.

We find ourselves at a pivotal moment in our evolution as a species. Pivotal moments pop up a lot on the Essence Map. They're designed to give us a kick in the seat of our pants. To propel us forward, to shake the foundations beneath us. They shift us from one state of being to another.

Most often we see them in our losses. In bereavement, the breakdown of a relationship, or in losing something we hold dear. That event becomes the pivotal moment or ending. There is life before that point and life after, and it is no longer the same. What was our normal has gone forever.

But what comes in its place is always where we are meant to be. We make great leaps forward across the chasm that is the Void in which we find ourselves. Our losses create the bridge across to the other side.

In [Boot Club](https://agentlerpace.co.uk/bootclub/) we recognised that the whole world had experienced a pivotal moment in the past year or so. We had also entered the place that I call the Void. The new beginning is yet to come. But, be assured, it's on its way.

This gives us a great opportunity because it is in the Void that we create the new. It's where ideas emerge and creativity is on the rise. We begin to reconnect to our truth and our essence. Another layer of our selves has been peeled away to reveal yet more of who we really are.

Now, this is happening on a global scale.

I'm fascinated by the concept that the world around us is merely an illusion, a construct that we each create, based on our past conditioning and life experiences. I've experimented with this idea and have seen how my perception of the world is influenced by my thoughts about it.