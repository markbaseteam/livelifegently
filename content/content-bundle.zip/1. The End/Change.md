Red

Root Chakra

Kindalini energy

  

You must give up the life you planned …

  

Instinct 

Survival

Security

  

The Route Map

Milestones

Starting Out

Change

Cycles of Change

  

Change is part of life, and without wanting to put a dampener on things, change prepares us for our final transition from life to death, the return of our souls to the Cosmos. Like all things/change, we can do that the easy or the hard way. 

  

We can’t escape change. It’s with us from birth. Adapting from the care of our families socialising at nursery or junior school. All of these different times in our lives require us to embrace change. Our first relationship, our first break up. Our first job, our first job loss. Bereavement. All milestones that ask us to adapt. To go from one type of reality to another. Each time we are changed. Each experience leaves its mark on us. We walk through fire to varying degrees and we emerge, altered.

That alteration depends on how much we need to learn, and how much we need to let go.

As we go through loss and change, we recognise the pattern. We begin to anticipate how we will feel.

We begin to understand the purpose of change and to recognise what it leaves in its wake. We see that, although traumatic at the time, even the most profound loss can bring positives to our life, it we let it.