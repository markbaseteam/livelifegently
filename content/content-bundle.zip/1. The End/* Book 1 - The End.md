**Chapter 1 - The End of the World as We Know It**

>It's the end of the world as we know it, and I feel fine  
(It's time I had some time alone) ~ REM

[[1.1 A Global Pivotal Moment]]
[[1.2 Endings and pivotal moments]]
[[1.3 - The End]]
[[1.4 A Normal Life]]
1.5 How is it the start of changing the world?
1.6 Examples of the end in the world 
[[1.7 Excavating our true selves]] 
[[1.8 How do you find your truth?]]
1.9 Practices 
[[1.10 How do you experience the End?]] 
1.11 Chris' story 
[[1.12 How do you emerge?]] 
[[1.13 The End - Reconnect]]
[[1.14 - Endings and Pivotal Moments]]

- [[1.1 The beginning is often the end]]
- [[1.2 The secret to change]]
- [[1.3 Seed]]

**Chapter 2 - How it all began**

[[2.1 Where it all began]]
[[2.2 My philosophy of life]]
[[2.3 My Credo]]
2.4 The Journey back to you
[[2.5 Don't die with your music still inside you]]

My Journey
It's all been leading to this
Coming into focus

**Chapter 3 - The Essence Map**

[[3.1 how the essence map came about]]
[[3.2 The Essence Map - an Overview]] 
3.3 What is Essence? Wyrd, Web of Wyrd
3.4
3.5 [[3.5 Live your Truth]]
[[3.6 Where are you now?]]
3.7 A Journey Back Home
3.8 Milestones
[[3.9 The End - Reconnect - Mind]] 
3.10 What is the End? 

**Chapter 4 - We Start at the End**

[[4.1 A crisis is a holy summons to cross a threshold]]
[[4.2 Look for endings if you want a new beginning]]

Your world is ending
A new normal
The old is gone
Why we should embrace endings

**Chapter 5 - Change and Loss**

[[5.1 when your life changes, it changes you]]
[[5.2 Chaos and change]] 
[[5.3 Cosmos v Chaos]]

Trust
Faith
Chose
Put you on a new path
Can't see the path yet
[[5.X Changes]]
[[5.Y Chaos]]

**Chapter 6 - Lessons in Loss**

1
2
3
4
5

**Chapter 7 - Change helps you find your Truth**

[[7.1 Wounds are doors]]
[[7.2 why walking through the fire is our way home]]
7.3 Why change is a catalyst
7.4 Why we fear change

**Chapter 8 - Unfolding**

[[8.1 we are unbroken]]

Peeling back the layers

**Chapter 9 - Letting go**

[[9.1 Release and let go]]
[[9.2 The difference between letting go and the need to let go]]
[[9.3 how letting go helps us find our way home]]
[[9.4 You must be able to do 3 things]]

No normal

**Chapter 10 - Light at the end of the Tunnel**

[[10.1 The Blind Woodturner]]
[[10.2 the blind woodturner and the archetypal hero's journey]]

Chris' Story

**Chapter 11 - Love is the answer**

[[11.1 Fear or Love]]

**Chapter 12 - Change your World, Change the World**

[[12.1 how to save the world by starting with you]]
[[12.2 We create our future]]
[[12.3 Awaken the unique spark]]
[[12.4 Consciousness - Climate Change]]
[[12.5 A new world can arise]]

The first step in changing the world around you
The End is just the Beginning

[[12.6 What sort of world do you want to live in?]]
[[12.7 What kind of world do you want to live in]]
[[12.8 The Adjustment Bureau]]
[[12.9 how we can create the world we want to live in]]